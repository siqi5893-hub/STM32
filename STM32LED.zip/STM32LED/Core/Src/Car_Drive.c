#include "main.h"
#include "tim.h"
#include "Car_Drive.h"

/// @brief 前进
/// @param speed 速度 0~99
void Car_Forward(uint16_t speed)
{
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1, speed); // 左轮 前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2, 0);     // 左轮不后退
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_3, speed); // 右轮 前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_4, 0);     // 右轮不后退
}

/// @brief 后退
/// @param speed 速度 0~99
void Car_Backward(uint16_t speed)
{
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1, 0);     // 左轮不前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2, speed); // 左轮 后退
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_3, 0);     // 右轮不前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_4, speed); // 右轮 后退
}
/// @brief 原地左转
/// @param speed 速度 0~99
void Car_RotateLeft(uint16_t speed)
{
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1, 0);//左轮不前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2, speed);//左轮后拉
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_3, speed);//右轮前拉
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_4, 0);//右轮不后退
}
/// @brief 原地右转
/// @param speed 速度 0~99
void Car_RotateRight(uint16_t speed)
{
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1, speed);//左轮前拉
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2, 0);//左轮不后退
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_3, 0);//右轮前拉
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_4, speed);//右轮不后退
}
/// @brief 左前进
/// @param speed_low 速度 0~50
/// @param speed_high 速度 50~99
void Wheel_MA1_ForwardLeft(uint16_t speed_low)
{
  // 左轮前进，速度低
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1, speed_low); //左轮低速前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2, 0);//不后退
}
void Wheel_MA2_ForwardRight(uint16_t speed_high)
{
  // 右轮前进，速度高
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_3, speed_high);//右轮高速前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_4, 0);// 不后退
}
void Car_ForwardLeft(uint16_t speed_low, uint16_t speed_high)
{
  Wheel_MA1_ForwardLeft(speed_low);
  Wheel_MA2_ForwardRight(speed_high);
}
/// @brief 右前进
/// @param speed_low 速度 0~50
/// @param speed_high 速度 50~99
void Wheel_MB1_ForwardLeft(uint16_t speed_high)
{
  // 左轮前进，速度高
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1, speed_high);//左轮高速前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2, 0);//不后退
}
void Wheel_MB2_ForwardRight(uint16_t speed_low)
{
  // 右轮前进，速度低
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_3, speed_low);//右轮低速前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_4, 0);// 不后退
}
void Car_ForwardRight(uint16_t speed_low, uint16_t speed_high)
{
  Wheel_MB1_ForwardLeft(speed_high);
  Wheel_MB2_ForwardRight(speed_low);
}
/// @brief 左后退
/// @param speed_low 速度 0~50
/// @param speed_high 速度 50~99
void Wheel_MA1_BackLeft(uint16_t speed_low, uint16_t speed_high)
{
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1, 0);//不前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2, speed_low);//左轮低速后退
}
void Wheel_MA2_BackRight(uint16_t speed_low, uint16_t speed_high)
{
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_3, 0);//不前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_4, speed_high);//右轮高速后退
}
void Car_BackwardLeft(uint16_t speed_low, uint16_t speed_high)
{
  Wheel_MA1_BackLeft(speed_low, speed_high);
  Wheel_MA2_BackRight(speed_low, speed_high);
}
/// @brief 右后退
/// @param speed_low 速度 0~50
/// @param speed_high 速度 50~99
void Wheel_MB1_BackLeft(uint16_t speed_low, uint16_t speed_high)
{
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1, 0);//不前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2, speed_high);//左轮高速后退
}
void Wheel_MB2_BackRight(uint16_t speed_low, uint16_t speed_high)
{
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_3, 0);//不前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_4, speed_low);//右轮低速后退
}
void Car_BackwardRight(uint16_t speed_low, uint16_t speed_high)
{
  Wheel_MB1_BackLeft(speed_low, speed_high);
  Wheel_MB2_BackRight(speed_low, speed_high);
}
/// @brief 电机制动(动能回收)
void Car_Brake(void)
{
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1, 99);//左轮全力前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2, 99);//左轮全力后退
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_3, 99);//右轮全力前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_4, 99);//右轮全力后退
}
void Car_Brake_WithDelay(uint16_t delay_time)
{
  Car_Brake();
  HAL_Delay(delay_time);
}
/// @brief 空挡滑行
void Car_Slide(void)
{
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_1, 0);//左轮不前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_2, 0);//左轮不后退
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_3, 0);//右轮不前进
  __HAL_TIM_SetCompare(&htim4, TIM_CHANNEL_4, 0);//右轮不后退
}
void Car_Slide_WithDelay(uint16_t delay_time)
{
  Car_Slide();
  HAL_Delay(delay_time);
}