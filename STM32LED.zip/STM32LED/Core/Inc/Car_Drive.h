#ifndef CAR_DRIVE_H
#define CAR_DRIVE_H
#include "main.h"
void SystemClock_Config(void);
void Car_Forward(uint16_t speed);// 前进
void Car_Backward(uint16_t speed);// 后退
void Car_RotateLeft(uint16_t speed);// 左转
void Car_RotateRight(uint16_t speed);// 右转
void Car_ForwardLeft(uint16_t speed_low, uint16_t speed_high);// 左前进
void Car_ForwardRight(uint16_t speed_low, uint16_t speed_high);// 右前进
void Car_BackwardLeft(uint16_t speed_low, uint16_t speed_high);// 左后退
void Car_BackwardRight(uint16_t speed_low, uint16_t speed_high);// 右后退
void Car_Brake(void);// 电机制动（动能回收）
void Car_Brake_WithDelay(uint16_t delay_time);// 电机制动（动能回收）并延时
void Car_Slide(void);// 空挡滑行
void Car_Slide_WithDelay(uint16_t delay_time);// 空挡滑行并延时
#endif